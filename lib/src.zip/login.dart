import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'services/auth_service.dart';
import 'register.dart';
import 'home.dart';
import 'admin_home.dart';
import 'faturino_home.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  bool _obscurePassword = true;
  bool _isLoading = false;
  String? _errorMessage;
  String _language = 'sq';

  final AuthService _authService = AuthService();

  String t(String sq, String en) => _language == 'sq' ? sq : en;

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  Future<void> _handleLogin() async {
    if (_emailController.text.isEmpty || _passwordController.text.isEmpty) {
      setState(() => _errorMessage = t('Ju lutem plotësoni të gjitha fushat.', 'Please fill in all fields.'));
      return;
    }

    setState(() { _isLoading = true; _errorMessage = null; });

    final error = await _authService.login(
      email: _emailController.text.trim(),
      password: _passwordController.text.trim(),
    );

    setState(() => _isLoading = false);

    if (error == null) {
      final role = await _authService.getUserRole();
      if (mounted) {
        Navigator.pushReplacement(context, MaterialPageRoute(
          builder: (_) => (role == 'line_admin' || role == 'super_admin')
              ? const AdminHomePage()
              : role == 'faturino'
                  ? const FatorinoHomePage()
                  : const HomePage(),
        ));
      }
    } else if (error == 'inactive') {
      setState(() => _errorMessage = t(
        'Llogaria juaj është çaktivizuar. Kontaktoni administratorin.',
        'Your account has been deactivated. Contact your administrator.',
      ));
    } else if ((error.contains('wrong-password') || error.contains('invalid-credential') || error.contains('user-not-found') || error.contains('INVALID_LOGIN_CREDENTIALS'))) {
      setState(() => _errorMessage = t(
        'Email ose fjalëkalimi gabim.',
        'Wrong email or password.',
      ));
    } else {
      // Show actual error for debugging
      setState(() => _errorMessage = error ?? 'Unknown error');
    }
  }

  void _showForgotPasswordDialog() {
    final emailCtrl = TextEditingController(text: _emailController.text.trim());
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text(
          t('Rivendos fjalëkalimin', 'Reset password'),
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
        ),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(
            t(
              'Shkruani emailin tuaj dhe do t\'ju dërgojmë një link.',
              'Enter your email and we\'ll send you a reset link.',
            ),
            style: const TextStyle(color: Colors.grey, fontSize: 14),
          ),
          const SizedBox(height: 16),
          TextField(
            controller: emailCtrl,
            keyboardType: TextInputType.emailAddress,
            autofocus: true,
            decoration: InputDecoration(
              labelText: 'Email',
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              prefixIcon: const Icon(Icons.email_outlined),
            ),
          ),
        ]),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: Text(t('Anulo', 'Cancel')),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF3A7DFF),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            onPressed: () async {
              final email = emailCtrl.text.trim();
              if (email.isEmpty) return;
              Navigator.pop(dialogContext);
              try {
                await FirebaseAuth.instance.sendPasswordResetEmail(email: email);
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text(t(
                      'Link-u u dërgua! Kontrolloni emailin tuaj.',
                      'Reset link sent! Check your email.',
                    )),
                    backgroundColor: const Color(0xFF00C853),
                  ));
                }
              } catch (_) {
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text(t('Email nuk u gjet.', 'Email not found.')),
                    backgroundColor: Colors.red,
                  ));
                }
              }
            },
            child: Text(t('Dërgo', 'Send'), style: const TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF2F6FB),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
          child: Column(children: [

            // Language switcher
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                _LangBall(flag: '🇦🇱', label: 'SQ', selected: _language == 'sq', onTap: () => setState(() => _language = 'sq')),
                const SizedBox(width: 8),
                _LangBall(flag: '🇬🇧', label: 'EN', selected: _language == 'en', onTap: () => setState(() => _language = 'en')),
              ],
            ),

            const SizedBox(height: 30),

            // Logo
            Container(
              width: 120, height: 120,
              decoration: BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
                boxShadow: [BoxShadow(color: const Color(0xFF3A7DFF).withOpacity(0.15), blurRadius: 30, offset: const Offset(0, 10))],
              ),
              child: const Center(child: Text('🚌', style: TextStyle(fontSize: 56))),
            ),

            const SizedBox(height: 14),
            const Text('URBANE', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, letterSpacing: 2)),
            Text(t('Aplikacioni i Transportit', 'Transport App'), style: const TextStyle(color: Colors.grey)),
            const SizedBox(height: 32),

            // Card
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [BoxShadow(blurRadius: 15, color: Colors.grey.withOpacity(0.15), offset: const Offset(0, 8))],
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

                Text(
                  t('Hyr në llogarinë tënde', 'Login to your account'),
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Color(0xFF3A7DFF)),
                ),
                const SizedBox(height: 20),

                // Email
                _buildField(
                  controller: _emailController,
                  hint: 'Email',
                  icon: Icons.email_outlined,
                  keyboardType: TextInputType.emailAddress,
                ),
                const SizedBox(height: 14),

                // Password
                _buildField(
                  controller: _passwordController,
                  hint: t('Fjalëkalimi', 'Password'),
                  icon: Icons.lock_outline,
                  obscure: _obscurePassword,
                  suffix: IconButton(
                    icon: Icon(
                      _obscurePassword ? Icons.visibility_outlined : Icons.visibility_off_outlined,
                      color: Colors.grey, size: 20,
                    ),
                    onPressed: () => setState(() => _obscurePassword = !_obscurePassword),
                  ),
                ),
                const SizedBox(height: 6),

                // Forgot password
                Align(
                  alignment: Alignment.centerRight,
                  child: TextButton(
                    onPressed: _showForgotPasswordDialog,
                    style: TextButton.styleFrom(padding: EdgeInsets.zero, minimumSize: const Size(10, 36)),
                    child: Text(
                      t('Keni harruar fjalëkalimin?', 'Forgot password?'),
                      style: const TextStyle(color: Color(0xFF3A7DFF), fontSize: 13),
                    ),
                  ),
                ),

                // Error
                if (_errorMessage != null) ...[
                  const SizedBox(height: 4),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    decoration: BoxDecoration(
                      color: Colors.red.shade50,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: Colors.red.shade200),
                    ),
                    child: Text(_errorMessage!, style: TextStyle(color: Colors.red.shade700, fontSize: 13)),
                  ),
                  const SizedBox(height: 12),
                ],

                const SizedBox(height: 4),

                // Login button
                SizedBox(
                  width: double.infinity, height: 50,
                  child: ElevatedButton(
                    onPressed: _isLoading ? null : _handleLogin,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF3A7DFF),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      elevation: 3,
                    ),
                    child: _isLoading
                        ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
                        : Text(t('Hyr', 'Login'), style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white)),
                  ),
                ),

                const SizedBox(height: 20),

                // Register link
                Center(
                  child: GestureDetector(
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const RegisterPage())),
                    child: RichText(
                      text: TextSpan(
                        text: t('Nuk keni një llogari? ', "Don't have an account? "),
                        style: const TextStyle(color: Colors.grey, fontSize: 14),
                        children: [
                          TextSpan(
                            text: t('Regjistrohu', 'Register'),
                            style: const TextStyle(color: Color(0xFF3A7DFF), fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),

              ]),
            ),
            const SizedBox(height: 20),
          ]),
        ),
      ),
    );
  }

  Widget _buildField({
    required TextEditingController controller,
    required String hint,
    required IconData icon,
    bool obscure = false,
    Widget? suffix,
    TextInputType? keyboardType,
  }) {
    return TextField(
      controller: controller,
      obscureText: obscure,
      keyboardType: keyboardType,
      style: const TextStyle(fontSize: 14),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.grey, fontSize: 13),
        prefixIcon: Icon(icon, color: const Color(0xFF3A7DFF), size: 20),
        suffixIcon: suffix,
        filled: true,
        fillColor: const Color(0xFFF8FAFF),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFF3A7DFF), width: 1.5)),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
    );
  }
}

class _LangBall extends StatelessWidget {
  final String flag;
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _LangBall({required this.flag, required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: selected ? const Color(0xFF3A7DFF) : Colors.white,
          borderRadius: BorderRadius.circular(20),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.08), blurRadius: 8)],
        ),
        child: Row(children: [
          Text(flag, style: const TextStyle(fontSize: 16)),
          const SizedBox(width: 4),
          Text(label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: selected ? Colors.white : Colors.grey)),
        ]),
      ),
    );
  }
}